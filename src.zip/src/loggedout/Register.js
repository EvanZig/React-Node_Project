import React,  { useState, useRef } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css'
import {Button , Form, Container, Card, InputGroup, Modal} from 'react-bootstrap'
import axios from 'axios';

export default function Register(){

  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const [matchingPasswords, setMatchingPasswords] = useState(true)

  const firstNameInput = useRef();
  const lastNameInput = useRef();
  const ageInput = useRef();
  const dateOfBirthInput = useRef();
  const emailAddressInput = useRef();
  const passwordInput = useRef();
  const passwordConfirm = useRef();

  function handleSubmit(event){
      event.preventDefault();
      const data = {
        firstname: firstNameInput.current.value,
        lastname: lastNameInput.current.value,
        age: ageInput.current.value,
        dateOfBirth: dateOfBirthInput.current.value,
        email: emailAddressInput.current.value,
        password: passwordInput.current.value,
      };
      if(passwordConfirm.current.value !== passwordInput.current.value){
        setMatchingPasswords(false)
        return;
      }
      console.log(data)
      axios.post("http://localhost:3000/register", data)
      .then(response => {
        console.log(response.data);
      })
      .catch(error => {
        console.error(error);
      })
      console.log(data);
  }
  
    return (
        <div>
          <Form onSubmit={handleSubmit}>
          <Button variant="primary" onClick={handleShow}>
          REGISTER
          </Button>

          <Modal show={show} onHide={handleClose}>
          <Modal.Header closeButton>
          <Modal.Title>registration</Modal.Title>
          </Modal.Header>
          <Modal.Body>

          <Container>
                <Card className="px-4">
                  <Card.Body>
                    <div className="mb-3 mt-md-4">
                      <h2 className="fw-bold mb-2 text-center text-uppercase ">
                        REGISTER
                      </h2>
                      <div className="mb-3">
                          <Form.Group className="mb-3" controlId="Firstname">
                            <Form.Label className="text-center">Firstname</Form.Label>
                            <Form.Control type="text" placeholder="Enter Name" ref={firstNameInput}/>
                          </Form.Group>

                          <Form.Group className="mb-3" controlId="Lastname">
                            <Form.Label className="text-center">Lastname</Form.Label>
                            <Form.Control type="text" placeholder="Enter Name" ref={lastNameInput} />
                          </Form.Group>

                          <InputGroup className="mb-3">
                          <InputGroup.Text>Age</InputGroup.Text>
                          <Form.Control type="text" ref={ageInput}/>
                          </InputGroup>

                          <Form.Group className="mb-3">
                          <Form.Label className="text-center"> Date of birth </Form.Label>
                          <Form.Control type="date" name='date_of_birth' ref={dateOfBirthInput}/>
                          </Form.Group>

                          <Form.Group className="mb-3" controlId="formBasicEmail">
                            <Form.Label className="text-center">
                              Email address
                            </Form.Label>
                            <Form.Control type="email" placeholder="Enter email" ref={emailAddressInput} />
                          </Form.Group>
    
                          <Form.Group className="mb-3" controlId="Password">
                            <Form.Label>Password</Form.Label>
                            <Form.Control type="password" placeholder="Password" ref={passwordInput} />
                            <div className ="errorLogin">{matchingPasswords ? "": "passwords dont match"}</div>
                          </Form.Group>

                          <Form.Group
                            className="mb-3"
                            controlId="confirmPassword"
                          >
                            <Form.Label>Confirm Password</Form.Label>
                            <Form.Control type="password" placeholder="Password" ref = {passwordConfirm} />
                            <div className ="errorLogin">{matchingPasswords ? "": "passwords dont match"}</div>
                          </Form.Group>

                      </div>
                    </div>
                  </Card.Body>
                </Card>
          </Container>

            </Modal.Body>
          <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button type="submit" variant="primary" onClick={handleSubmit}>
            Create Account
          </Button>
          </Modal.Footer>
          </Modal>
          </Form>
        </div>
      );
}