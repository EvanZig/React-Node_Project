import React, {useState, useRef } from 'react'
import {Button, Form} from 'react-bootstrap'
import 'bootstrap/dist/css/bootstrap.min.css'
import axios from 'axios'

export default function DeleteProfile(){

    const [isDeleting, setIsDeleting] = useState(false)
    const idDelete = useRef();
    

    const handleDelete = (event) => {
        event.preventDefault()
        setIsDeleting(true);
        axios.delete("http://localhost:3000/loggedin/delete?id=" + idDelete.current.value)
          .then(response => {
            console.log('User deleted successfully:', response.data);
            setIsDeleting(false);
          })
          .catch(error => {
            console.error('Error deleting user:', error);
            setIsDeleting(false);
          });
      };

    return (
      <Form className ="delete" onSubmit={handleDelete}>
        <Button className='deleteButton' disabled = {isDeleting} type="submit">
           {isDeleting ? 'Deleting...' : 'Delete Profile'}
        </Button>
        <Form.Control className ="deleteInput" type="text" ref={idDelete} ></Form.Control>
        </Form>
    )
}